import os
import requests
from colorama import Fore
from time import sleep

def clear_sc():
    os.system('clear') 

def consultar():
    clear_sc()
    print(Fore.BLUE + 'INSIRA O NOME DA BASE JUNTO COM O FORMATO EX: (BASE.TXT)')
    print(Fore.BLUE + '============================================================')
    es = input('nome da base #>')
    clear_sc()
    site = input('site desejado #>')
    clear_sc()
    try:
        with open(es,'r') as linees:
            liness = len(linees.readlines())
            print(Fore.BLUE + f'PROCURANDO POR: {site}')
            print(Fore.BLUE + '============================================================')
            print(f'''
cripto: https://|http://
+
wordlist: /{es}/
+
wordlist size: {liness} characters
+
expected request code: 200
+
unexpected request codes: 404|403|503|405
''')
    except:
        clear_sc()
        print(Fore.RED + 'BASE DE DADOS NÃO ENCONTRADA')
        sleep(2)
        
    print(Fore.BLUE + '============================================================')
    try:
        with open(es, 'r') as file:
            for line in file:
                if site in line:
                    try:
                        fog = line.strip().split()
                        url = fog[0]
                        response = requests.get(url)
                        response_code = response.status_code
                        if response_code == 404 or response_code == 403 or response_code == 503 or response_code == 405:
                            coloramas = Fore.RED
                        
                        elif response_code == 200:
                            coloramas = Fore.BLUE
                    except:
                        response_code = 'N/A'
                        coloramas = Fore.RED
                        
                    print(coloramas + f'[code: {response_code}] >> ',Fore.WHITE + line.strip())
                    sleep(0.6)
        continuee = input(Fore.RED + 'aperte enter para continuar:')
    except:
        sair = input(Fore.RED + 'APERTE ENTER PARA CONTINUAR:')
        sleep(2)
while True:
    consultar()

import os
import requests
import socket
import os
import glob
from colorama import Fore
from time import sleep

def clear_sc():
    os.system('clear')

def search_in_wordlists(site):
    clear_sc()
    caminho_da_pasta = 'WordLists'
    arquivos_txt = glob.glob(os.path.join(caminho_da_pasta,'*.txt'))

    for wl in arquivos_txt:
        try:
            response = requests.get('https://httpbin.org/ip')
            ip_address = response.json()['origin']
            responseg = requests.get(f'http://ip-api.com/json/{ip_address}')
            location = responseg.json()['country']
            regi = responseg.json()['regionName']
            with open(wl,'r') as linees:
                liness = len(linees.readlines())
            print(Fore.BLUE + f'PROCURANDO POR: {site} em {wl}')
            print(Fore.BLUE + '============================================================')
            print(f'''
ip-address: {ip_address} | {location} | {regi}
+
cripto: https://|http://
+
wordlist: /{wl}/
+
wordlist size: {liness} characters
+
expected request code: 200
+
unexpected request codes: 400|404|403|503|405
                 ''')
            print(Fore.BLUE + '============================================================')   
        except:
            clear_sc()
            print(Fore.RED + 'BASE DE DADOS NÃO ENCONTRADA')
            sleep(2)
            return     
        
        with open(wl, 'r') as file:
            for line in file:
                if site in line:
                    try:
                        fog = line.strip().split()
                        url = fog[0]
                        response = requests.get(url)
                        response_code = response.status_code
                        if response_code == 404 or response_code == 403 or response_code == 503 or response_code == 405 or response_code == 400:
                            coloramas = Fore.RED
                        
                        elif response_code == 200:
                            coloramas = Fore.BLUE
                    except:
                        response_code = 'N/A'
                        coloramas = Fore.RED
                          
                    print(coloramas + f'[code: {response_code}] >> ',Fore.WHITE + line.strip())  
            print(Fore.BLUE + '============================================================')   
           

def consultar():
    clear_sc()
    print(Fore.BLUE + '''ESCREVA O LINK OU NOME DO SITE ABAIXO
=====================================''')
    site = input('>>')
    search_in_wordlists(site)
    
consultar()
